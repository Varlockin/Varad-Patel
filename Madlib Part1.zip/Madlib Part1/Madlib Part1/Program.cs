﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Madlib_Part1
{
    class Program
    {
        //Varad Patel & Avi Patel
        //COM30S
        //MADLIB Part 1
        static void Main(string[] args)
        {
            
            string adj3;
            string creature;
            string est;
            string adj1;
            string adj2;
            string color1;
            string verb;
            string noun;
            string color2;
            string clothing;
            string adj4;
            string planet;
            string story;
            
            Console.WriteLine("--------");
            Console.WriteLine(" MADLIB!");
            Console.WriteLine("--------");

            string titletext = @"
               _   .-')      ('-.     _ .-') _                   .-. .-')   
              ( '.( OO )_   ( OO ).-.( (  OO) )                  \  ( OO )  
               ,--.   ,--.) / . --. / \     .'_  ,--.      ,-.-') ;-----.\  
               |   `.'   |  | \-.  \  ,`'--..._) |  |.-')  |  |OO)| .-.  |  
               |         |.-'-'  |  | |  |  \  ' |  | OO ) |  |  \| '-' /_) 
               |  |'.'|  | \| |_.'  | |  |   ' | |  |`-' | |  |(_/| .-. `.  
               |  |   |  |  |  .-.  | |  |   / :(|  '---.',|  |_.'| |  \  | 
               |  |   |  |  |  | |  | |  '--'  / |      |(_|  |   | '--'  / 
               `--'   `--'  `--' `--' `-------'  `------'  `--'   `------'    ";

            Console.WriteLine(titletext);
            Console.WriteLine("\nLet's Start");
            Console.ReadLine();
 
            
            Console.Write("Please enter an adjective: ");
            adj1 = Console.ReadLine();

            Console.Write("Please enter an adjective: ");
            adj2 = Console.ReadLine();

            Console.Write("Please enter an adjective: ");
            adj3 = Console.ReadLine();

            Console.Write("Please enter an adjective: ");
            adj4 = Console.ReadLine();

            Console.Write("Please enter an adjective (ending with -est): ");
            est = Console.ReadLine();

            Console.Write("Please enter a color: ");
            color1 = Console.ReadLine();

            Console.Write("Please enter a color: ");
            color2 = Console.ReadLine();

            Console.Write("Please enter an action verb: ");
            verb = Console.ReadLine();

            Console.Write("Please enter a noun: ");
            noun = Console.ReadLine();

            Console.Write("Please enter an adjective (clothing): ");
            clothing = Console.ReadLine();

            Console.Write("Please enter a mythical creature (plural): ");
            creature = Console.ReadLine();

            Console.Write("Please enter a planet: ");
            planet = Console.ReadLine();

            story = "In every human being's back yard, lives a bush. And in that bush lies a secret passageway to the Land of " + adj1 + " fish"+
                ". \nYou must seek out your secret pathway, and go there! \nIn this land, " + creature +
                " gather to create the " + est + " of potions. \nThese potions will make you " + adj2 + ", " + adj3 + ", " + color1 +
                ", and even give you the ability to " + verb + ". \nHere, you can also learn how to cook " + noun + " in a " + color2 +
                " cauldron made out of " + clothing + ". \nYou'll be the most magical, " + adj4 + " kid on " + planet + ".";
            Console.WriteLine(story);

            Console.WriteLine("Please enter to exit");
            Console.ReadKey();

        }
    }
}
